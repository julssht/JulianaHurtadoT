function verificarCredenciales() {
    const usuario = document.getElementById('usuario').value;
    const contrasena = document.getElementById('contrasena').value;
    const errorMessage = document.getElementById('error-message');

    if (usuario === 'cenfo' && contrasena === '123') {
        errorMessage.style.display = 'none';
        // Redirect to landing page
        window.location.href = '/landing.html';
    } else {
        errorMessage.style.display = 'block';
    }
}