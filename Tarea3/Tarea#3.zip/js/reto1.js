document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');

    const infoFactura = document.getElementById('info-factura');
    const fechaSpan = document.getElementById('fecha');
    const clienteInput = document.getElementById('cliente');
    const clienteSpan = document.getElementById('cliente-factura');

    const cantidadInput = document.getElementById('cantidad');
    const cantidadSpan = document.getElementById('cantidad-factura');
    const precioInput = document.getElementById('precio');
    const precioSpan = document.getElementById('precio-factura');
    const articuloInput = document.getElementById('articulo');
    const articuloSpan = document.getElementById('articulo-factura');

    const subtotalSpan = document.getElementById('subtotal-factura');
    const ivaSpan = document.getElementById('iva-factura');
    const servicioSpan = document.getElementById('servicio-factura');
    const totalSpan = document.getElementById('total-factura');

    cantidadInput.addEventListener('input', function(event) {
        this.value = this.value.replace(/[^0-9]/g, '');
    });

    precioInput.addEventListener('input', function(event) {
        this.value = this.value.replace(/[^0-9.]/g, '');
    });

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        if (!clienteInput.value || !articuloInput.value || !cantidadInput.value || !precioInput.value) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Todos los campos son obligatorios.',
                timer: 1500
            });
            return;
        }

        const today = new Date();
        const formattedDate = today.toLocaleDateString('es-ES', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
        clienteSpan.textContent = clienteInput.value;
        fechaSpan.textContent = formattedDate;

        // info detalle articulo
        articuloSpan.textContent = articuloInput.value;
        cantidadSpan.textContent = cantidadInput.value;
        precioSpan.textContent = precioInput.value;

        // calculo de subtotal
        const subtotal = cantidadInput.value * precioInput.value;
        subtotalSpan.textContent = subtotal;

        // calculo de iva
        const iva = subtotal * 0.13;
        ivaSpan.textContent = iva;

        // calculo de servicio
        const servicio = subtotal * 0.05;
        servicioSpan.textContent = servicio;

        // calculo de total
        const total = subtotal + iva + servicio;
        totalSpan.textContent = total;

        infoFactura.style.display = 'block';
        Swal.fire({
            icon: 'success',
            title: 'Factura generada',
            text: 'La factura se ha generado correctamente.',
            timer: 1500
        });
    });
});
