document.addEventListener('DOMContentLoaded', function() {
    const input_buscador_cedula = document.getElementById('buscador');
    const btn_buscar = document.getElementById('buscar-empleado');
    const resultado_busqueda = document.getElementById('info-resultado-busqueda');
    const resultado_no_encontrado = document.getElementById('datos-empleado-vacio');

    // outputs de resultado de información
    const nombre_empleado = document.getElementById('nombre-empleado');
    const apellidos_empleado = document.getElementById('apellido-empleado');
    const lugar_empleado = document.getElementById('lugar-empleado');
    const foto_empleado = document.getElementById('foto-empleado');

    let empleados = [
        {
            cedula: '109110338',
            nombre: 'Juan',
            apellidos: 'Pérez Soto',
            lugar: 'San José',
            foto: 'images/reto10/chico.png'
        },
        {
            cedula: '209110338',
            nombre: 'María',
            apellidos: 'González Rodríguez',
            lugar: 'Heredia',
            foto: 'images/reto10/muslimah.png'
        },
        {
            cedula: '309110338',
            nombre: 'Pedro',
            apellidos: 'Rodríguez Pérez',
            lugar: 'Alajuela',
            foto: 'images/reto10/policia.png'
        },
        {
            cedula: '409110338',
            nombre: 'Ana',
            apellidos: 'Hernández Soto',
            lugar: 'Cartago',
            foto: 'images/reto10/abuela.png'
        },
        {
            cedula: '509110338',
            nombre: 'Karla',
            apellidos: 'Jiménez Rodríguez',
            lugar: 'Guanacaste',
            foto: 'images/reto10/mujer.png'
        }
    ];

    input_buscador_cedula.addEventListener("input", validarLargoCedula);
    input_buscador_cedula.addEventListener("keypress", validarInputNumerico);

    btn_buscar.addEventListener('click', function(event) {
        event.preventDefault();

        if (!cedulaValida()) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'La cédula debe tener 9 dígitos.',
                timer: 1500
            });
            return;
        }

        let empleado = empleados.find(empleado => empleado.cedula === input_buscador_cedula.value);

        if (empleado) {
            resultado_no_encontrado.style.display = 'none';
            resultado_no_encontrado.classList.remove('empleado-vacio');

            nombre_empleado.textContent = empleado.nombre;
            apellidos_empleado.textContent = empleado.apellidos;
            lugar_empleado.textContent = empleado.lugar;
            foto_empleado.src = empleado.foto;

            if (!resultado_busqueda.classList.contains('empleado-mostrado')) {
                resultado_busqueda.classList.add('empleado-mostrado');
            }
            
            resultado_busqueda.style.display = 'block';

        } else {
            resultado_busqueda.style.display = 'none';
            resultado_busqueda.classList.remove('empleado-mostrado');

            if (resultado_no_encontrado.classList.contains('empleado-vacio')) {
                resultado_no_encontrado.classList.remove('empleado-vacio');
            }
            resultado_no_encontrado.style.display = 'block';
        }
    });

    // validacion de inputs
    function validarInputNumerico(e) {
        const re = /[0-9]/;
        if (!re.test(e.key)) {
            e.preventDefault();
        }
    }

    function validarLargoCedula() {
        if (input_buscador_cedula.value.length > 9) {
            input_buscador_cedula.value = input_buscador_cedula.value.slice(0, 9);
        }
    }

    function cedulaValida() {
        // Validar que la cédula sea válida
        if (input_buscador_cedula.value.length < 9) {
            return false;
        }

        return true;
    }
});