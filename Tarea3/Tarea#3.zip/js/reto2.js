document.addEventListener('DOMContentLoaded', function() {
    const formConvertirDolares = document.getElementById('form-convertir-dolares');
    const formConvertirColones = document.getElementById('form-convertir-colones');

    // resultados de conversion
    const resultadoConversionDolares = document.getElementById('resultado-convertir-dolares');
    const resultadoConversionColones = document.getElementById('resultado-convertir-colones');

    // tipo de cambio de dolar
    const montoDolaresInput = document.getElementById('monto-dolares');
    const tipoCambioDolarInput = document.getElementById('tipo-cambio-dolar');
    const montoConvertidoColonesSpan = document.getElementById('monto-convertido-colones');

    // tipo de cambio de colones
    const montoColonesInput = document.getElementById('monto-colones');
    const tipoCambioColonesInput = document.getElementById('tipo-cambio-colon');
    const montoConvertidoDolaresSpan = document.getElementById('monto-convertido-dolares');
    
    function validarInput(event) {
        const re = /^[0-9]+(\.[0-9]{0,2})?$/;
        if (!re.test(event.target.value)) {
            event.target.value = event.target.value.slice(0, -1);
        }   
    }

    // validacion de inputs
    montoDolaresInput.addEventListener('input', validarInput);

    tipoCambioDolarInput.addEventListener('input', validarInput);

    montoColonesInput.addEventListener('input', validarInput);

    tipoCambioColonesInput.addEventListener('input', validarInput);

    formConvertirDolares.addEventListener('submit', function(event) {
        event.preventDefault();

        const montoDolares = parseFloat(montoDolaresInput.value);
        const tipoCambioDolar = parseFloat(tipoCambioDolarInput.value);
        let montoConvertidoColones = montoDolares * tipoCambioDolar;

        // mostrar solo dos decimales en caso que haya decimales
        montoConvertidoColones = montoConvertidoColones.toFixed(2);

        montoConvertidoColonesSpan.textContent = montoConvertidoColones;

        resultadoConversionDolares.style.display = 'block';
    });

    formConvertirColones.addEventListener('submit', function(event) {
        event.preventDefault();

        const montoColones = parseFloat(montoColonesInput.value);
        const tipoCambioColones = parseFloat(tipoCambioColonesInput.value);
        let montoConvertidoDolares = montoColones / tipoCambioColones;

        // mostrar solo dos decimales en caso que haya decimales
        montoConvertidoDolares = montoConvertidoDolares.toFixed(2);

        montoConvertidoDolaresSpan.textContent = montoConvertidoDolares;

        resultadoConversionColones.style.display = 'block';
    });
});