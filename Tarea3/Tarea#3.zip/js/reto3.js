document.addEventListener("DOMContentLoaded", function() {
    const select_perfumes = document.getElementById("perfumes-select");

    select_perfumes.addEventListener("change", function() {
        const valor_seleccionado = select_perfumes.value;

        if (valor_seleccionado === "bvlgari") {
            // Abrir la página de Bvlgari
            window.open("https://www.bulgari.com/es-es/perfumes?srsltid=AfmBOooSHGI53yuSxXHy-NV_FfxTQPsKqOSASjkG5RziPyNIOMrlhJAr")

            // Limpiar el select
            select_perfumes.value = "";
        } else if (valor_seleccionado === "calvin-klein") {
            // Abrir la página de Calvin Klein
            window.open("https://www.calvinklein.es/perfumes-mujeres")

            // Limpiar el select
            select_perfumes.value = "";
        } else if (valor_seleccionado === "dior") {
            // Abrir la página de Dior
            window.open("https://www.dior.com/en_int/beauty/fragrance/women-fragrance-home.html")

            // Limpiar el select
            select_perfumes.value = "";
        } else if (valor_seleccionado === "louis-vuitton") {
            // Abrir la página de Louis Vuitton
            window.open("https://la.louisvuitton.com/esp-mx/perfumes/colecciones/todos-los-perfumes/_/N-t1vibucj")

            // Limpiar el select
            select_perfumes.value = "";
        } else if (valor_seleccionado === "lacoste") {
            // Abrir la página de Lacoste
            window.open("https://www.lacoste.com/es/inicio/todos-los-productos/fragancias/")

            // Limpiar el select
            select_perfumes.value = "";
        }
    });
});