document.addEventListener('DOMContentLoaded', function() {
    const perfumesSelect = document.getElementById('perfumes-select');
    const perfumeImage = document.getElementById('perfume-image');

    perfumesSelect.addEventListener('change', function() {
        const selectedValue = this.value;
        let imageUrl = '';

        switch (selectedValue) {
            case '1':
                imageUrl = 'images/reto4/Perfumes_Bvlgari.jpg';
                break;
            case '2':
                imageUrl = 'images/reto4/Perfumes_CK.jpg';
                break;
            case '3':
                imageUrl = 'images/reto4/Perfumes_Dior.jpg';
                break;
            case '4':
                imageUrl = 'images/reto4/Perfumes_LV.jpg';
                break;
            case '5':
                imageUrl = 'images/reto4/Perfumes_Lacoste.jpg';
                break;
            default:
                imageUrl = '';
        }

        if (imageUrl) {
            perfumeImage.src = imageUrl;
            perfumeImage.style.display = 'block';
        } else {
            perfumeImage.style.display = 'none';
        }
    });
});
