document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("calcularBtn").addEventListener("click", function() {
        const modelo = document.getElementById("combo1").value;
        const version = document.getElementById("combo2").value;
        const imagen = document.getElementById("carro-image");
        const precioTexto = document.getElementById("precio");
        const ivaPrecioTexto = document.getElementById("iva-precio");
        const totalPrecioTexto = document.getElementById("total-precio");

        if (!modelo || !version) {
            Swal.fire("Error", "Por favor selecciona ambas opciones.", "error");
            return;
        }

        let precio = calcularPrecio(modelo, version);
        imagen.src = `images/reto5/${modelo}_${version}.webp`;
        imagen.style.display = "block";
        precioTexto.innerHTML = `Precio estimado: ₡${precio.toLocaleString()}`;
        ivaPrecioTexto.innerHTML = `IVA (13%): ₡${(precio * 0.13).toLocaleString()}`;
        totalPrecioTexto.innerHTML = `Precio total: ₡${(precio * 1.13).toLocaleString()}`;
    });

    function calcularPrecio(modelo, version) {
        const precios = {
            "rangerover_base": 75000000,
            "rangerover_full": 87000000,
            "xtrail_base": 22000000,
            "xtrail_full": 26000000
        };
        return precios[`${modelo}_${version}`] || 0;
    }
});
