document.addEventListener('DOMContentLoaded', function() {
    const colores = ["blanco", "blanco_perlado", "cement_gray", "silver_metallic", "negro", "rojo"];
    let indiceActual = 0;
    const imagen = document.getElementById("yaris-image");
    const listaColores = document.getElementById("color-list");

    function actualizarImagen() {
        imagen.src = `images/reto6/yaris_${colores[indiceActual]}.png`;
        imagen.alt = "Toyota Yaris " + colores[indiceActual];
        actualizarListaColores();
    }

    function actualizarListaColores() {
        const coloresVisibles = getColoresVisibles();
        listaColores.innerHTML = coloresVisibles.map((color, indice) => {
            return `<li${indice === Math.floor(coloresVisibles.length / 2) ? ' class="active"' : ''}>
                        <div class="color-box" style="background-color: ${getColorCode(color)};"></div>
                    </li>`;
        }).join('');
    }

    function getColorCode(color) {
        const colorCodes = {
            "blanco": "#FFFFFF",
            "blanco_perlado": "#e0e2e4",
            "cement_gray": "#474d4b",
            "silver_metallic": "#c6c8ca",
            "negro": "#0f0f0f",
            "rojo": "#a90d1a"
        };
        return colorCodes[color] || "#FFFFFF";
    }

    function getColoresVisibles() {
        const visibleCount = 3; // numero de colores visibles en el carrusel
        const mitad = Math.floor(visibleCount / 2);
        const coloresVisibles = [];

        for (let i = -mitad; i <= mitad; i++) {
            const indice = (indiceActual + i + colores.length) % colores.length;
            coloresVisibles.push(colores[indice]);
        }

        return coloresVisibles;
    }

    document.getElementById("prevBtn").addEventListener("click", function() {
        indiceActual = (indiceActual === 0) ? colores.length - 1 : indiceActual - 1; // si es el primer color, ir al último
        imagen.classList.add('fade-out');
        setTimeout(() => {
            actualizarImagen();
            imagen.classList.remove('fade-out');
        }, 250);
    });

    document.getElementById("nextBtn").addEventListener("click", function() {
        indiceActual = (indiceActual === colores.length - 1) ? 0 : indiceActual + 1; // si es el último color, regresar al primero
        setTimeout(() => {
            actualizarImagen();
        }, 250);
    });

    actualizarImagen(); // para iniciar con la primer imagen
});