document.addEventListener('DOMContentLoaded', function() {
    // areas de imagen
    const area_velvet_blue_mask = document.getElementById('area-velvet-blue-mask');
    const area_velvet_exotic_leather = document.getElementById('area-velvet-exotic-leather');
    const area_velvet_black_patchouli = document.getElementById('area-velvet-black-patchouli');
    const area_velvet_infusion = document.getElementById('area-velvet-infusion');
    const area_velvet_desert_oud = document.getElementById('area-velvet-desert-oud');
    const area_velvet_zafferano = document.getElementById('area-velvet-zafferano');

    // variables para información de los detalles del perfume
    const titulo_descripcion = document.getElementById('titulo-descripcion-perfume');
    const parrafo_descripcion = document.getElementById('parrafo-descripcion-perfume');

    area_velvet_blue_mask.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Blue Mask';
        parrafo_descripcion.innerHTML = "Dolce&Gabbana Velvet Blue Musk, inspirado en Sicilia, narra una historia que se desarrolla sumida en las embriagadoras fragancias que impregnan las calles y los palacios de la isla, decorados con relucientes oros y toques de lapislázuli que brillan bajo el sol del Mediterráneo.<br><br>\
                                            Como una dulce brisa envolvente que se alza de los antiguos monumentos árabes, Dolce&Gabbana Velvet Blue Musk rinde homenaje al musgo a través de la sensualidad cálida y brillante, en una alquimia de azafrán y delicadas notas de preciosa rosa damascena.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });

    area_velvet_exotic_leather.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Exotic Leather';
        parrafo_descripcion.innerHTML = "Las atmósferas exóticas de un fumoir del siglo XVIII se unen a la nobleza del cuero italiano. Dolce&Gabbana Velvet Exotic Leather, intensa y sensual, acompaña a nuestra mente por un misterioso viaje en el tiempo.<br><br>\
                                            Dolce&Gabbana Velvet Exotic Leather es una potente fórmula de carácter viril que seduce con sus notas de cuero, canela e incienso, evocando la atmósfera del fumoir del Palazzo Mirto, residencia histórica situada en el corazón de Palermo.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });

    area_velvet_black_patchouli.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Black Patchouli';
        parrafo_descripcion.innerHTML = "Muchedumbres de gente en unos embarcaderos en los que pica el sol, que hablan en idiomas lejanos, con olores misteriosos y embriagadores. Dolce&Gabbana Velvet Black Patchouli es el símbolo del proficuo intercambio entre culturas que ha marcado la historia de Sicilia.<br><br>\
                                            Dolce&Gabbana Velvet Black Patchouli rinde homenaje a la historia que abre las puertas hacia oriente, con una composición compleja que mezcla deliciosas notas de naranja tarocco, aceite de pachuli y absoluto de jara: una fragancia enigmática que evoca la extraordinaria fusión de culturas de Sicilia.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });

    area_velvet_infusion.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Infusion';
        parrafo_descripcion.innerHTML = "Dolce&Gabbana Velvet Infusion, realizada como homenaje a unos de los regalos más preciados de Asia al mundo occidental, es una fragancia amaderada y cítrica que plasma la esencia de una fusión de culturas donde el té negro se encuentra con los luminosos cítricos italianos.<br><br>\
                                            En una unión armoniosa de aromas, Dolce&Gabbana Velvet Infusion captura el cuerpo de las hojas de té negro, que se combinan perfectamente con la esencia efervescente de las mandarinas y las bergamotas italianas, para crear una experiencia sensorial atemporal que trasciende las tradiciones y las culturas.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });

    area_velvet_desert_oud.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Desert Oud';
        parrafo_descripcion.innerHTML = "El poder místico del viento que sopla entre las dunas del desierto, contenido en un perfume que expresa los aromas del incienso y el oud: Dolce&Gabbana Velvet Desert Oud, una fragancia fuera de lo común de la colección Velvet que combina misterio y seducción en su esencia.<br><br>\
                                            Rodeado de un encanto lleno de misterio, Dolce&Gabbana Velvet Desert Oud relata una historia de suntuosidad y seducción que se desarrolla entre notas de tabaco, azafrán y oud. Una fragancia creada con los mejores ingredientes, donde oriente y occidente se funden.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });

    area_velvet_zafferano.addEventListener('click', function() {
        titulo_descripcion.textContent = 'Velvet Zafferano';
        parrafo_descripcion.innerHTML = "Intensa y especiada, cálida y sensual. Dolce&Gabbana Velvet Zafferano, la nueva fragancia de la Velvet Collection, rinde homenaje al azafrán: una especia valiosa cargada de historia y simbolismo, que ocupa un lugar especial en la historia y la cultura de Italia.<br><br>\
                                            Rico y opulento, el azafrán, la especia protagonista de la fragancia Dolce&Gabbana Velvet Zafferano, se contrapone a la sensación ardiente de las hojas doradas de tabaco. Se trata de una alquimia única que da como resultado una fusión cálida y sensual de pachuli amaderado, vainilla cautivadora y jara ambarina, y crea una estela embriagadora que persiste en la piel.<br><br>\
                                            La fragancia pertenece a la exclusiva Velvet Collection de Dolce&Gabbana, una serie de perfumes de lujo adornados con un toque de terciopelo suntuoso que invitan a descubrir y explorar la dedicación de la marca a la artesanía. Un viaje íntimo y auténtico a través de los recuerdos olfativos de los diseñadores y su amor por Italia.";
    });
});