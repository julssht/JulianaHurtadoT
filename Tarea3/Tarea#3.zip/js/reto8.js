document.addEventListener('DOMContentLoaded', function() {
    const nombre_coleccion_storage_compras = 'reto8-registro-compras';

    // Seleccionar los elementos del formulario
    const input_producto = document.getElementById('producto');
    const input_tienda = document.getElementById('tienda');
    const input_fecha = document.getElementById('fecha');
    const input_precio = document.getElementById('precio');
    const input_cantidad = document.getElementById('cantidad');

    const btn_registrar_compra = document.getElementById('registrar-compra');

    // variables para mostrar la consulta
    const producto_consulta = document.getElementById('producto-consulta');
    const tienda_consulta = document.getElementById('tienda-consulta');
    const fecha_consulta = document.getElementById('fecha-consulta');
    const precio_consulta = document.getElementById('precio-consulta');
    const cantidad_consulta = document.getElementById('cantidad-consulta');

    // Select para mostrar las compras registradas
    const select_productos = document.getElementById('productos-select');

    const btn_consultar_compra = document.getElementById('consultar-compra');

    // evento para validar que solo se pueda ingresar números en el campo de precio
    input_precio.addEventListener('keypress', validarInputNumerico);

    // evento para validar que solo se pueda ingresar números en el campo de cantidad
    input_cantidad.addEventListener('keypress', validarInputNumerico);

    // evento para registrar la compra
    btn_registrar_compra.addEventListener('click', registrarCompra);

    // evento para mostrar la compra seleccionada
    btn_consultar_compra.addEventListener('click', function () {
        let index = select_productos.value;
        if (index === '') {
            Swal.fire({
                icon:"error",
                title: "Error", 
                text: "Por favor selecciona una compra.",
                timer: 1500
            });
            return;
        }

        let historial_compras = obtenerCompras();
        let compra = historial_compras[index];

        producto_consulta.innerHTML = compra.producto;
        tienda_consulta.innerHTML = compra.tienda;
        fecha_consulta.innerHTML = compra.fecha;
        precio_consulta.innerHTML = compra.precio;
        cantidad_consulta.innerHTML = compra.cantidad;
    });

    function validarInputNumerico(e) {
        const re = /[0-9]/;
        if (!re.test(e.key)) {
            e.preventDefault();
        }
    }

    // Función para registrar la compra
    function registrarCompra(e) {
        e.preventDefault();

        // Obtener los valores de los inputs
        let producto = input_producto.value;
        let tienda = input_tienda.value;
        let fecha = input_fecha.value;
        let precio = input_precio.value;
        let cantidad = input_cantidad.value;

        // Validar que los campos no estén vacíos
        if (producto === '' || tienda === '' || fecha === '' || precio === '' || cantidad === '') {
            Swal.fire({
                icon:"error",
                title: "Error", 
                text: "Por favor llena todos los campos.",
                timer: 1500
            });
            return;
        }

        // Crear un objeto con los datos de la compra
        let compra = {
            producto: producto,
            tienda: tienda,
            fecha: fecha,
            precio: precio,
            cantidad: cantidad
        };

        try {
            // Obtener el historial existente
            let historial_compras = obtenerCompras();

            // Agregar la nueva compra al historial
            historial_compras.push(compra);

            // Guardar el historial actualizado en el JSON
            localStorage.setItem(nombre_coleccion_storage_compras, JSON.stringify(historial_compras));

            // Mostrar las compras en el select
            mostrarComprasSelect();

            Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 1000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            }).fire({
                icon: 'success',
                title: 'Compra registrada'
            });
        } catch (error) {
            Swal.fire({
                icon:"error",
                title: "Error", 
                text: "No se pudo registrar la compra."
            });
            return;
        }

        // Limpiar los inputs
        input_producto.value = '';
        input_tienda.value = '';
        input_fecha.value = '';
        input_precio.value = '';
        input_cantidad.value = '';
    }

    // Función para obtener las compras registradas
    function obtenerCompras() {
        let compras = localStorage.getItem(nombre_coleccion_storage_compras);
        return compras ? JSON.parse(compras) : [];
    }

    // Función para mostrar las compras en el select
    function mostrarComprasSelect() {
        let historial_compras = obtenerCompras();
        select_productos.innerHTML = '<option value="">Selecciona una compra</option>';

        historial_compras.forEach((compra, index) => {
            let option = document.createElement('option');
            option.value = index;
            option.innerHTML = `${compra.producto} - ${compra.tienda} - ${compra.fecha}`;
            select_productos.appendChild(option);
        });
    }

    // Mostrar las compras al cargar la página
    mostrarComprasSelect();
});