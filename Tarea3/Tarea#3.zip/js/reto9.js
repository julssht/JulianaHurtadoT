document.addEventListener('DOMContentLoaded', function() {
    const nombre_coleccion_storage_votaciones = 'reto9-votaciones';

    // Seleccionar los elementos del formulario
    const input_nombre = document.getElementById('nombre');
    const input_cedula = document.getElementById('cedula');
    const input_correo = document.getElementById('correo');
    const input_fecha_nacimiento = document.getElementById('fecha-nacimiento');

    const btn_votar = document.getElementById('votar');

    // Evento para validar que solo se pueda ingresar números en el campo de cédula
    input_cedula.addEventListener('keypress', validarInputNumerico);
    input_cedula.addEventListener('input', validarLargoCedula);

    // Evento para manejar el envío del formulario
    btn_votar.addEventListener('click', function(event) {
        event.preventDefault();

        if (input_nombre.value === '' || input_cedula.value === '' || input_correo.value === '' || input_fecha_nacimiento.value === '') {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Por favor completa todos los campos.',
                timer: 1500
            });
            return;
        }

        if (!cedulaValida()) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'La cédula debe tener 9 dígitos.',
                timer: 1500
            });
            return;
        }

        if (!correoValido()) {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Por favor ingresa un correo válido.',
                timer: 1500
            });
            return;
        }

        // Obtener el valor del input radio seleccionado
        const voto_seleccionado = document.querySelector('input[name="voto"]:checked');

        if (voto_seleccionado) {

            let historial_votaciones = obtenerVotaciones();

            // Crear un objeto con los datos del formulario
            let voto = {
                nombre: input_nombre.value,
                cedula: input_cedula.value,
                correo: input_correo.value,
                fecha_nacimiento: input_fecha_nacimiento.value,
                partido: voto_seleccionado.value
            };

            // Agregar el voto al historial
            historial_votaciones.push(voto);

            // Guardar el historial actualizado en el JSON
            localStorage.setItem(nombre_coleccion_storage_votaciones, JSON.stringify(historial_votaciones));

            input_nombre.value = '';
            input_cedula.value = '';
            input_correo.value = '';
            input_fecha_nacimiento.value = '';
            document.querySelector('input[name="voto"]:checked').checked = false;

            // Mostrar mensaje de éxito y reporte de votaciones luego
            Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 1000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer);
                    toast.addEventListener('mouseleave', Swal.resumeTimer);
                }
            }).fire({
                icon: 'success',
                title: 'Voto registrado'
            }).then(() => {
                Swal.fire({
                    title: "<strong>Reporte Votaciones</strong>",
                    icon: "info",
                    html: `
                        <table border="1" style="width: 100%; text-align: center;">
                            <tr>
                                <th>Nombre</th>
                                <th>Cédula</th>
                                <th>Correo</th>
                                <th>Fecha de nacimiento</th>
                                <th>Partido</th>
                            </tr>
                            ${historial_votaciones.map(voto => `
                                <tr>
                                    <td>${voto.nombre}</td>
                                    <td>${voto.cedula}</td>
                                    <td>${voto.correo}</td>
                                    <td>${voto.fecha_nacimiento}</td>
                                    <td>${voto.partido}</td>
                                </tr>
                            `).join('')}
                        </table>
                        <br>
                        <h2>Total de votos por partido</h2>
                        <ul style="list-style-type: none;">
                            <li><strong>Partido A:</strong> ${historial_votaciones.filter(voto => voto.partido === 'PartidoA').length}</li>
                            <li><strong>Partido B</strong>: ${historial_votaciones.filter(voto => voto.partido === 'PartidoB').length}</li>
                            <li><strong>Partido C</strong>: ${historial_votaciones.filter(voto => voto.partido === 'PartidoC').length}</li>
                        </ul>
                    `,
                    showCloseButton: true,
                    width: '50%',
                    position: 'center'
                });
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Por favor selecciona un partido para votar.',
                timer: 1500
            });
        }
    });

    function validarInputNumerico(e) {
        const re = /[0-9]/;
        if (!re.test(e.key)) {
            e.preventDefault();
        }
    }

    function validarLargoCedula() {
        if (input_cedula.value.length > 9) {
            input_cedula.value = input_cedula.value.slice(0, 9);
        }
    }

    function cedulaValida() {
        // Validar que la cédula sea válida
        if (input_cedula.value.length < 9) {
            return false;
        }

        return true;
    }

    function correoValido() {
        // Validar que el correo sea válido
        const re = /\S+@\S+\.\S+/;
        return re.test(input_correo.value);
    }

    function obtenerVotaciones() {
        let votaciones = localStorage.getItem(nombre_coleccion_storage_votaciones);
        return votaciones ? JSON.parse(votaciones) : [];
    }
});